from unicodedata import name
import logging
from utils.token import TOKEN
import utils.murkups as nav
from utils.db import Database
from aiogram import Bot, Dispatcher, executor, types

logging.basicConfig(level=logging.INFO)

bot = Bot(token = TOKEN)
dp = Dispatcher(bot)

db = Database('utils\database.db')

@dp.message_handler(commands=['start'])
async def start (message: types.Message):
    if (not db.user_exists(message.from_user.id)):
        db.add_user(message.from_user.id)
        await bot.send_message(message.from_user.id, "Укажите ваш ник")
    else:
        await bot.send_message(message.from_user.id, "Вы уже зарегистрированы!", reply_markup=nav.mainMenu)

@dp.message_handler()
async def bot_message(message: types.Message):
    if message.chat.type == 'private':
        if message.text == 'ПРОФИЛЬ':
            await bot.send_message(message.from_user.id, "Данная функция находится в разработке", reply_markup=nav.mainMenu)
        elif message.text == 'ПОДПИСКА':
            await bot.send_message(message.from_user.id, "Данная функция находится в разработке", reply_markup=nav.mainMenu)
        else:
            if db.get_signup(message.from_user.id) == "setnickname":
                if(len(message.text) > 20):
                    await bot.send_message(message.from_user.id, "Ник не должен превышать 20 символов")
                elif '@' in message.text or '/' in message.text:
                    await bot.send_message(message.from_user.id, "Вы ввели запрещенный символ")

                else:
                    db.set_nickname(message.from_user.id, message.text)
                    db.set_signup(message.from_user.id, "done")
                    await bot.send_message(message.from_user.id, "Вы успешно зарегистрированы!", reply_markup=nav.mainMenu)
            else:
                await bot.send_message(message.from_user.id, "Что?")       






if __name__ == '__main__': 
    executor.start_polling(dp, skip_updates=True)